export function addPenny() {
return  {
    type: 'addPenny'
  };
}

export function addNickle() {
  return {
    type: 'addNickle'
  };
}

export function addDime() {
  return {
    type: 'addDime'
  };
}

export function addQuarter() {
  return {
    type: 'addQuarter'
  };
}
