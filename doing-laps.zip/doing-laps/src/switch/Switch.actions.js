export function flipSwitch() {
  return {
    type: 'flip'
  };
}
